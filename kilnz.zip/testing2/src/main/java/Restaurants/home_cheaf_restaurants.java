package Restaurants;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class home_cheaf_restaurants {
	
	ChromeDriver n;
	@Test(priority = 0)
	public void website() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Documents\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
		n = new ChromeDriver();
		
		n.get("https://kilnz.com");
		
		n.manage().window().maximize();
		
        n.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	
	@Test(priority = 1)
	public void Click_on_the_Login_button() throws InterruptedException	{
		
		Thread.sleep(2000);
		
		n.findElement(By.xpath("//button[@data-target='#login']")).click();
	}
	
	 @Test(priority = 2)
		public void EnterTheUsername() throws InterruptedException{
		   
		  
		   n.findElement(By.xpath("//input[@id='email']")).sendKeys("mkavi9630@gmail.com");
		   
			Thread.sleep(2000);
	   }
	 
	 @Test(priority = 3)
		public void EnterThePassword() throws InterruptedException{
		   
		   n.findElement(By.xpath("//input[@id='password']")).sendKeys("1234567890");
	   }
	 
	 @Test(priority = 4)
		public void clickloginbutton() throws InterruptedException{
		   
	  n.findElement(By.xpath("//input[@name='remember']")).click();
	   
	   n.findElement(By.xpath("//button[@class='btn-theme btn-block login_submit']")).click();
//	   
	   Thread.sleep(2000);
	   
	   
	   }
//	 @Test(priority = 5)
//		public void click_New_orders() throws InterruptedException{
//		 
//		 
//		 n.findElement(By.xpath("/html/body/section/div/div/div[1]/div/div[1]/a/div/h6")).click();
//		 
//		 Thread.sleep(2000);
//		 
//	 }
	 
//	    @Test(priority = 6)
//		public void search_name() throws InterruptedException{
//		 
//		 n.findElement(By.name("search_all")).sendKeys("KILNZ24124P05180009");
//		 
//		 Thread.sleep(2000);
//		 
//		 //click on the filter option 
//		 n.findElement(By.xpath("//button[@class='btn-theme btn-block search-all-filter']")).click();
//		 
//		 Thread.sleep(2000);
//		 
//	 }
//	 
//	    @Test(priority = 7)
//		public void clear_the_search_the_name() throws InterruptedException{
//		 
//		 n.findElement(By.name("search_all")).clear();
//		 
//		 Thread.sleep(2000);
//		 
//		 n.findElement(By.xpath("//button[@class='btn-theme btn-block search-all-filter']")).click();
//		 
//		 Thread.sleep(2000);
//		 
//	    n.navigate().back();
//	    
//	    Thread.sleep(2000);
//	 }
	 
	 
	    @Test(priority = 8)
		public void All_orders() throws InterruptedException{
	    	
	    	n.findElement(By.xpath("//h6[contains(text(), 'All Orders')]")).click();
	    	
	    	Thread.sleep(2000);
	    	
	    	
	    }

	    @Test(priority = 9)
		public void Search() throws InterruptedException{
	    	
	    	  n.findElement(By.name("search_all")).sendKeys("KILNZ24124P05300002"); 
	    	  
	    	  Thread.sleep(2000);
	    	  
//	    	  Select k = new Select(n.findElement(By.name("search")));
//	    	  
//	  		  k.selectByIndex(1);
	    	  
	  		 Thread.sleep(2000);
	  		 
	    	  //filter option
	    	  n.findElement(By.xpath("//button[@class='btn-theme mr-1 btn-block search-all-filter']")).click();
	    	  
	    	  Thread.sleep(2000);  
	    	  
//	    	  n.findElement(By.name("search_all")).clear();
//	    	  
//	    	  Thread.sleep(2000);
	    	  
	    	  //filter option
//	    	  n. findElement(By.xpath("//button[@class='btn-theme mr-1 btn-block search-all-filter']")).click();
	    	  
	    	  
	    	
	    }
	    
	    @Test(priority = 10)
		public void Reset() throws InterruptedException{
	    	
	    	 Thread.sleep(2000);
	    	
	    	n.findElement(By.xpath("//button[@class='btn-sec btn-block']")).click();
	    	
	    	 Thread.sleep(2000);
	    	 
//	    	 n.navigate().back();
//	    	 
//
//	    	 Thread.sleep(2000); 
//	    	 
//	    	 n.navigate().forward();
	    	
	    }
	    
	    @Test(priority = 11)
		public void Order_accepted() throws InterruptedException{
	    	
	    	Thread.sleep(2000); 
	    	 
	    	
	    	n.findElement(By.xpath("//button[@data-id='1179']")).click();
	    	
	    	 Thread.sleep(2000);
	    	
	    	Alert d3 = n.switchTo().alert();
			d3.accept();	
	    }
	    
	    @Test(priority = 12)
		public void Send_to_Kitchen() throws InterruptedException{
	    	
	    	 Thread.sleep(2000);
	    	
	    	  n.findElement(By.xpath("//button[@data-id='1179']")).click();
	    	
	    	 Thread.sleep(2000);
	    	 
	    	 Alert d3 = n.switchTo().alert();
		     d3.accept();	
		     
		     Thread.sleep(2000);     
	    	
	    }
	    
	        @Test(priority = 13)
	  		public void order_ready() throws InterruptedException{
	        	
	        	 n.findElement(By.xpath("//button[@data-id='1179']")).click();
	        	 
	        	 Thread.sleep(2000);
		    	 
		    	 Alert d3 = n.switchTo().alert();
			     d3.accept(); 	
	        }
	        
	        @Test(priority = 14)
	  		public void order_completed() throws InterruptedException{
	        	
                 n.findElement(By.xpath("//button[@data-id='1179']")).click();
	        	 
	        	 Thread.sleep(2000);
		    	 
		    	 Alert d3 = n.switchTo().alert();
		    	 
			     d3.accept(); 
			     
			     n.quit();
	        	 	
	        }
	        
	        
	    
	  
	         
	 

}
