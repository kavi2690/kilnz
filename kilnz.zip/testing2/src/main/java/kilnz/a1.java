package kilnz;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class a1 {
	
	
	ChromeDriver n ;
	
	  
	@Test(priority =0)
	public void Visitweb()
   {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Documents\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
		
		n= new ChromeDriver();
		
		n.get("https://kilnz.com/");
		System.out.println("visiting web site");
		
		
		n.manage().window().maximize();
		
		
	}
	   @Test(priority = 1, groups="L")
		public void Login() throws InterruptedException{
		
			//click on the login button 
			n.findElement(By.xpath("//button[@class='btn btn-outline']")).click();
			
			Thread.sleep(2000);
			
		}
	   
	   @Test(priority = 2, groups="L")
		public void EnterTheUsername() throws InterruptedException{
		   
		  
		   n.findElement(By.xpath("//input[@id='email']")).sendKeys("kaviyarasu2916@gmail.com");
		   
			Thread.sleep(2000);
	   }
	   
	   @Test(priority = 3, groups="L")
		public void EnterThePassword() throws InterruptedException{
		   
		   n.findElement(By.xpath("//input[@id='password']")).sendKeys("Password@123");
	   }
	   
	   @Test(priority = 4, groups="L")
		public void clickloginbutton() throws InterruptedException{
		   
	 //  n.findElement(By.xpath("//input[@name='remember']")).click();
	   
	   n.findElement(By.xpath("//button[@class='btn-theme btn-block login_submit']")).click();
	   
	   Thread.sleep(2000);
	   
	   
	   }
	   
	   @Test(priority = 5, groups="L")
		public void Scrolldown() throws InterruptedException{
		   
		    n.executeScript("window.scrollBy(0,2000)");
			Thread.sleep(2000);
			
			n.executeScript("window.scrollBy(0,-1000)");
			Thread.sleep(2000);
		
	   }
	   
	   @Test(priority = 6, groups="L")
		public void HomeCheafRestaurant() throws InterruptedException{
		   
		  n.findElement(By.xpath("/html/body/div[5]/section/div/div/div[7]/div/a/img")).click();
		  Thread.sleep(2000);
	   
	   }
	   @Test(priority = 7, groups="L")
		public void Viewreview () throws InterruptedException{
		   
		    n.findElement(By.xpath("//button[@class='btn btn-outline-sm view_review_class']")).click();
		   
		   Thread.sleep(2000);
		   
		  
		   
	      n.findElement(By.xpath("//button[@class='close']")).click();
		   
	   }
	   
	  
		   
		   
	   
	   
	   @Test(priority =8, groups="L")
		public void clickasap () throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//a[@id='pickup-asap")).click();
	   }
		   
	   @Test(priority = 9, groups="L")
		public void SelectTheMenuTime () throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//div[@data-id='128']")).click();
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//*[@id=\"myModalFuturePickup\"]/div/div/form/div[1]/div/div/div[6]/div/div/div[1]/p")).click();
		   
	   }
	   
	   @Test(priority = 10, groups="L")
		public void LoadMyMenu () throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//button[@class='btn btn-theme-sm mx-3 pickup-load submit-pickup']")).click();
	   }
	   
	   @Test(priority = 11, groups="L")
		public void SearchTheName () throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//input[@class='form-control menusearch']")).sendKeys("Fishfry");
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//input[@class='form-control menusearch']")).clear();
		   
		   
	   }
	   
	   @Test(priority = 12, groups="L")
		public void checkBox () throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//input[@data-id='1']")).click();
		   
		   Thread.sleep(4000);
		   
		   n.findElement(By.xpath("//input[@data-id='0']")).click();
		   
		   
	   }
		   
	   @Test(priority = 13, groups="L")
		public void PageScroll () throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.executeScript("window.scrollBy(0,1000)");
		   
			Thread.sleep(2000);
			
			n.executeScript("window.scrollBy(0,-1000)");
			
			Thread.sleep(2000);
	   }
	   
	   @Test(priority = 14, groups="L")
		public void AddToCart () throws InterruptedException{
		   
		   n.findElement(By.xpath("//button[@data-food='375']")).click();
		   
		   Thread.sleep(2000);
	   }
	   
	   @Test(priority = 15, groups="L")
		public void RadioButton () throws InterruptedException{
		   
		   n.findElement(By.xpath("//input[@class='form-check-input variant_required']")).click();
		   
		   Thread.sleep(2000);
	   }
	   
	   @Test(priority = 16, groups="L")
		public void AddOn() throws InterruptedException{
		   
		   n.findElement(By.xpath("//*[@id=\\\"addtocartForm\\\"]/div[1]/div[2]/div/div/div[2]/div/input")).clear();
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//*[@id=\\\"addtocartForm\\\"]/div[1]/div[2]/div/div/div[2]/div/input")).sendKeys("3");
		   
	   }
	   
	   @Test(priority = 17, groups="L")
		public void qtyincrease() throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.name("menuqty")).clear();
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.name("menuqty")).sendKeys("2");
	   }
	   
	   @Test(priority = 18, groups="L")
		public void AddToCartSumbit() throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//button[contains(text(), 'Add to Cart')]")).click();
		   
		   Thread.sleep(2000);
	   }
	   
	   @Test(priority = 19, groups="L")
		public void Discount() throws InterruptedException{
		   
		   n.findElement(By.xpath("//p[contains(text(), 'Discount Coupon')]")).click();
		   

		   Thread.sleep(2000);
		   
		  n.findElement(By.xpath("//*[@id=\\\"coupon-new\\\"]/div/div/form/div/div/div[2]/div[1]/div[1]/strong")).click();
		   
	   }
	   @Test(priority = 20, groups="L")
		public void AddTip() throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//select[@id='tipsapply']")).click();
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//option[@value='10']")).click();
		   
		    
		   
	   }
	   @Test(priority = 21, groups="L")
		public void CheckOut() throws InterruptedException{
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//button[contains(text(), 'Checkout')]")).click();
	   }
	   
	   @Test(priority = 21, groups="L")
		public void cartpageandbilling() throws InterruptedException{
		   
		   n.findElement(By.name("next")).click();
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//*[@id=\"cusbilladdress77\"]/div/div/div/span[3]")).click();
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.name("next")).click();
		     
		   
	   }
	   
	   @Test(priority = 22, groups="L")
		public void payment() throws InterruptedException{
		   n.findElement(By.xpath("//*[@id=\"cuscard63\"]/div/div/div/span[2]")).click();
		   
		   Thread.sleep(2000);
		   
		   n.findElement(By.xpath("//button[@class='action-button submit_place']")).click();
		   
		   n.quit();
	   }
	   
	   

}
