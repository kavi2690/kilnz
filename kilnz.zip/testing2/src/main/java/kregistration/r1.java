package kregistration;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class r1 {
	
	ChromeDriver n;
	@Test(priority = 0)
	public void website() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Documents\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
		n = new ChromeDriver();
		
		n.get("https://kilnz.com");
		
		n.manage().window().maximize();
		
        n.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	
	@Test(priority = 1)
	public void Click_on_the_Login_button() throws InterruptedException	{
		
		Thread.sleep(2000);
		
		n.findElement(By.xpath("//button[@data-target='#login']")).click();
	}
	
	@Test(priority = 2)
	public void Register() throws InterruptedException {
		
		Thread.sleep(2000);
		
		n.findElement(By.xpath("//button[@data-dismiss='modal']")).click();
		
		Thread.sleep(2000);
			
		
	}
	
	@Test(priority = 3)
	public void first_name() throws InterruptedException{
		
		
		
		
		n.findElement(By.name("first_name")).sendKeys("kaviyarasu");
		
		Thread.sleep(2000);
		
	}
	
	@Test(priority = 4)
	public void Last_name() throws InterruptedException{
		
		n.findElement(By.name("last_name")).sendKeys("kavi");
		
		Thread.sleep(2000);
		
	}
	
	@Test(priority = 5)
	public void mobile_number() throws InterruptedException{
		
		n.findElement(By.name("mobile_no")).sendKeys("8866774455");
		
		
		
		
	}
	@Test(priority = 6)
	public void email() throws InterruptedException{
		
	
		//n.findElement(By.xpath("//input[@class='email']"))//*[@id="signup-form"]/input[5]
		//n.findElement(By.name("email")).sendKeys("k7630336@gmail.com");
		
		n.findElement(By.xpath("//*[@id=\"signup-form\"]/input[5]")).sendKeys("k7630336@gmail.com");
		
		Thread.sleep(2000);
		
	}
	
	@Test(priority = 7)
	public void Password() throws InterruptedException{
		
	//	n.findElement(By.name("password")).sendKeys("Password@123");
		
		n.findElement(By.xpath("//*[@id=\"signup-form\"]/input[6]")).sendKeys("Password@123");
		
		Thread.sleep(2000);
		
		//password_confirmation
		
		//n.findElement(By.name("password_confirmation")).sendKeys("Password@123");
		
		n.findElement(By.xpath("//*[@id=\"signup-form\"]/input[7]")).sendKeys("Password@123");
		
		Thread.sleep(2000);
		
	}
	
	@Test(priority = 7)
	public void Terms() throws InterruptedException{
		
		//n.findElement(By.xpath("//*[@id=\"signup-form\"]/div[1]/div/p/a")).click();
		
		n.findElement(By.linkText("Terms & Conditions.")).click();
		
		n.executeScript("window.scrollBy(0,2000)");
		Thread.sleep(2000);
		
		n.executeScript("window.scrollBy(0,-2000)");
		Thread.sleep(2000);
		
		n.navigate().back();
		
		Thread.sleep(2000);
		
	}
	@Test(priority = 8)
	public void Submit() throws InterruptedException{
		
		n.findElement(By.xpath("//button[@class='btn-theme btn-block signup_submit']")).click();
		
		Thread.sleep(2000);
		
		n.quit();
	}
	
	

	}
